package Adapter;

public class JsonMessageAdapter extends JsonMessage{
    JsonMessage j = new JsonMessage();

    public void getTest() {
        j.getMessage();
    }
}
