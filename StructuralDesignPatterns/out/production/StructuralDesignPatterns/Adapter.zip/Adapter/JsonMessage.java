package Adapter;

public class JsonMessage implements Message{
    public void getMessage(){
        System.out.println("JsonMessage");
    }
}
