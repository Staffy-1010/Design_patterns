package Adapter;

public class ByteMessageAdapter extends ByteMessage{
    ByteMessage b = new ByteMessage();

    public void getText(){
        b.getMessage();
    }
}
