package Adapter;

public class ByteMessage implements Message{
    public void getMessage(){
        System.out.println("ByteMessage");
    }
}
