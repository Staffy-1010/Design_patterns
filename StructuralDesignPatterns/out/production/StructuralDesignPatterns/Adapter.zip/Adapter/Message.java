package Adapter;

public interface Message {
    void getMessage();
}
