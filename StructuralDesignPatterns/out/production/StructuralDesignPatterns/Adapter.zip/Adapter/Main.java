package Adapter;

public class Main {
    public static void main(String[] args) {
        MessageAdapter m = new MessageAdapter();
        m.getMsg();
    }
}
