package Facade;

public class User {
    public String getUser(){
        return "Staffy";
    }
}
