package ObserverPattern;

public interface Observers {
    void update(String item);
}
