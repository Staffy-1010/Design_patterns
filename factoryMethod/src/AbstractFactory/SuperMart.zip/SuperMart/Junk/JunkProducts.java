package AbstractFactory.SuperMart.Junk;

public interface JunkProducts {
    void giveProducts();
}
