package AbstractFactory.SuperMart.Milk;

public interface DairyProducts {
    void giveProducts();
}
