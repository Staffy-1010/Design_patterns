package AbstractFactory.SuperMart.Factory;

import AbstractFactory.SuperMart.Grocery.GroceryProducts;

public abstract class GroceryFactory extends SuperMartFactory {
    public GroceryProducts getGrocery(){
        return null;
    }
}
