package AbstractFactory.SuperMart.Grocery;

public interface GroceryProducts {
    void giveProducts();
}
